# JLCSMT_LIB

#### 项目介绍
这是嘉立创SMT样品贴片中可贴片元器件列表_基础库  Altium Designer 集成库



